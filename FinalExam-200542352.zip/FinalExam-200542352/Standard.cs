using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200542352
{
    internal class Standard:User,iBillable
    {
        public string PostalCode;
        public string LibraryCardNumber;
        private string CreditCardNumber;

        public Standard()
    {
        PostalCode = string.Empty;
        LibraryCardNumber = string.Empty;
        CreditCardNumber = string.Empty;
    }

        public bool ProcessPayment()
        {
            return true;
        }
    }
}