using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200542352
{
    internal class Student:User
    {
        public int SchoolIDCard;
        public string CardNo;
        private DateTime BirthDate;

        public Student(int schoolIDcard)
    {
        SchoolIDCard = schoolIDcard;
        CardNo = string.Empty;
    }

    public DateTime DateOfBirth
    {
        get { return BirthDate; }
        set { BirthDate = value; }
    }

    }
}