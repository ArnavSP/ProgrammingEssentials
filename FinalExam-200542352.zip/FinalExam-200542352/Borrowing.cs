using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200542352 
{
    internal class Borrowing: iDownloadable
    {
        public int ReferenceNumber;
        public string UserIdentification;
        public DateTime BorrowStartDate;
        public DateTime BorrowEndDate;
        public bool PickedUp=false;
        public List<Resource> Resourcename;
        private static int _lastReferenceNumber = 0;

        public Borrowing(string userIdentification, List<Resource> resourcename)
        {
            UserIdentification = userIdentification;
            Resourcename = resourcename;
            ReferenceNumber = GenerateUniqueReferenceNumber();
        }
        
        private int GenerateUniqueReferenceNumber()
    {
        _lastReferenceNumber++;
        return _lastReferenceNumber;
    }

        public string GenerateAccessLink()
        {
            return "#1472583695";
        }

        public void ReturnResources(DateTime date)
        {
            if (date > this.BorrowEndDate)
            {
                Console.WriteLine("You need to pay fine for late return of resource!");
                this.PickedUp = true;
            }
            else
            {
                Console.WriteLine("Thank You!");
                this.PickedUp = true;
            }
        }
    }
}