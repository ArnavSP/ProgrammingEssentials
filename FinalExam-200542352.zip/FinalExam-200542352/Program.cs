﻿namespace FinalExam_200542352
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Standard obj=new Standard();

            obj.userID = 1;
            obj.firstName = "Arnav";
            obj.lastName = "Saini";
            obj.address = "F-318 New Palam";
            obj.phoneNumber = "1234567891";
            obj.PostalCode = "35446684";
            obj.LibraryCardNumber = "11111";

            Resource r1 = new Resource();
            r1.Title = "Book";
            r1.Code = "A999";
            r1.Description = "Spiderman Vol.1";
            r1.DatePublished = DateTime.Now;
            r1.Publisher = "Marvel Studios";

            Resource r2 = new Resource();
            r1.Title = "Magazine";
            r1.Code = "M999";
            r1.Description = "Times Now";
            r1.DatePublished = DateTime.Now;
            r1.Publisher = "Times Now Ltd.";

            List<Resource> resources=new List<Resource>();
            resources.Add(r1);
            resources.Add(r2);

            Borrowing b1 = new Borrowing(obj.userID.ToString(), resources);
            b1.BorrowStartDate = DateTime.Now;
            b1.BorrowEndDate = b1.BorrowStartDate.AddDays(10);


        }
    }
}